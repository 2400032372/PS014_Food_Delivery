package com.quickbite.order.dto;

import java.math.BigDecimal;

public record PaymentRequest(
        Long orderId,
        Long userId,
        BigDecimal amount
) {
}
